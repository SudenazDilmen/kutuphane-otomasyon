# Kütüphane Yönetim Sistemi

![Java](https://img.shields.io/badge/Java-11+-blue)
![MySQL](https://img.shields.io/badge/MySQL-5.7+-orange)
![JDBC](https://img.shields.io/badge/JDBC-4.2-lightgrey)

## 📌 Proje Açıklaması
Bu proje, bir kütüphane yönetim sistemi için geliştirilmiş Java tabanlı konsol uygulamasıdır. MySQL veritabanı entegrasyonu ile çalışarak kütüphane işlemlerini yönetmeyi sağlar.

## 🌟 Temel Özellikler
- ✔️ Kullanıcı kayıt ve giriş sistemi
- ✔️ Kitap ekleme/güncelleme/listeleme
- ✔️ Kitap ödünç alma/iade etme
- ✔️ Stok takibi
- ✔️ Bildirim sistemi

## 🛠️ Teknolojik Yapı
| Bileşen               | Açıklama                          |
|-----------------------|----------------------------------|
| **Java**             | Programlama dili                 |
| **MySQL**            | Veritabanı yönetimi             |
| **JDBC**             | Veritabanı bağlantı arayüzü     |
| **DAO Pattern**      | Veri erişim katmanı             |

## 📦 Paket Yapısı