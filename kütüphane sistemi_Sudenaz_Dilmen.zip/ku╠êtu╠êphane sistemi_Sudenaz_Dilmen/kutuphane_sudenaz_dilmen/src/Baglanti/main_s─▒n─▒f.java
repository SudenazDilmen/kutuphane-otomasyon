package Baglanti;

import java.util.Scanner;

public class main_sınıf {
    public static void main(String[] args) {
    	  IVeritabaniBaglantisi veritabaniBaglantisi = new MySQLVeritabaniBaglantisi();
          IKullaniciIslemleri kullaniciIslemleri = new KullaniciDepo(veritabaniBaglantisi);
          IKitapIslemleri kitapIslemleri = new KitapDepo(veritabaniBaglantisi);
          
          MenuYoneticisi menuYoneticisi = new MenuYoneticisi(kullaniciIslemleri, kitapIslemleri);
          menuYoneticisi.baslat();
    }
}
