package Baglanti;

public class Kullanici_sınıf {
    String isim;
    String sifre;
    String telNo;
    String mail;

    public Kullanici_sınıf(String isim , String telNo , String mail, String sifre) {
        this.isim = isim;
        this.telNo = telNo;
        this.mail = mail;
        this.sifre = sifre;
    }

    public String getSifre() {
        return sifre;
    }

    public void setSifre(String sifre) {
        this.sifre = sifre;
    }

    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public String getTelNo() {
        return telNo;
    }

    public void setTelNo(String telNo) {
        this.telNo = telNo;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }
}
