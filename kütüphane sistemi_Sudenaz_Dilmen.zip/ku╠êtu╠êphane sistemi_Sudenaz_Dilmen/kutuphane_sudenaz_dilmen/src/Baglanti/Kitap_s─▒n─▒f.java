package Baglanti;

public class Kitap_sınıf {
	    public String ad;
	    public String yazar;
	    public String yayinevi;
	    public int stok;
	    public String durum;
	    
	    
		public Kitap_sınıf(String ad, String yazar, String yayinevi, int stok, String durum) {
			super();
			this.ad = ad;
			this.yazar = yazar;
			this.yayinevi = yayinevi;
			this.stok = stok;
			this.durum = durum;
		}


		
		public String getAd() {
			return ad;
		}


		public void setAd(String ad) {
			this.ad = ad;
		}


		public String getYazar() {
			return yazar;
		}


		public void setYazar(String yazar) {
			this.yazar = yazar;
		}


		public String getYayinevi() {
			return yayinevi;
		}


		public void setYayinevi(String yayinevi) {
			this.yayinevi = yayinevi;
		}


		public int getStok() {
			return stok;
		}


		public void setStok(int stok) {
			this.stok = stok;
		}


		public String getDurum() {
			return durum;
		}


		public void setDurum(String durum) {
			this.durum = durum;
		}
	    
		
		
	    
}
