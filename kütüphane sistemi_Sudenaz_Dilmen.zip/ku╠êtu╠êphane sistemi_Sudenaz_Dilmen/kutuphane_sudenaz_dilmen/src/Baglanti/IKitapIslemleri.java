package Baglanti;

public interface IKitapIslemleri {
	boolean kitapEkle(Kitap_sınıf kitap);
    boolean kitapGuncelle(String ad, int yeniStok, String yeniDurum);
    void kitapAra(String arananAd);
    boolean kitapStokKontrol(String kitapAdi);
    boolean kitapOduncAl(String kullaniciAdi, String kitapAdi);
    boolean kitapIadeEt(String kullaniciAdi, String kitapAdi);
}
