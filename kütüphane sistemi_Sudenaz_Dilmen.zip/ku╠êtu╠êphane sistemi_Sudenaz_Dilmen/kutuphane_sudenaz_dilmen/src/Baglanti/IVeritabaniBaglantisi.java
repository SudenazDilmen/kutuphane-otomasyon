package Baglanti;

import java.sql.SQLException;

import com.mysql.jdbc.Connection;

public interface IVeritabaniBaglantisi {
	Connection baglan() throws SQLException;
}
