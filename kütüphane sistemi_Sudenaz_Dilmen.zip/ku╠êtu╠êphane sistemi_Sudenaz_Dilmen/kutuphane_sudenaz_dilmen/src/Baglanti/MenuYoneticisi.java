package Baglanti;

import java.util.Scanner;

public class MenuYoneticisi {
    private final Scanner scan;
    private final IKullaniciIslemleri kullaniciIslemleri;
    private final IKitapIslemleri kitapIslemleri;

    public MenuYoneticisi(IKullaniciIslemleri kullaniciIslemleri, IKitapIslemleri kitapIslemleri) {
        this.scan = new Scanner(System.in);
        this.kullaniciIslemleri = kullaniciIslemleri;
        this.kitapIslemleri = kitapIslemleri;
    }

    public void baslat() {
        boolean programDevam = true;
        boolean girisYapildi = false;
        String girisYapanKullanici = null;

        System.out.println("Kütüphane sistemine hoşgeldiniz!!");

        while (programDevam) {
            System.out.println("\nİşlem seçin:");
            System.out.println("1 - Kullanıcı İşlemleri");
            System.out.println("2 - Kitap İşlemleri");
            System.out.println("0 - Çıkış");
            System.out.print("Seçiminiz: ");
            int secim = scan.nextInt();
            scan.nextLine(); // dummy

            switch (secim) {
                case 1:
                    kullaniciIslemleriMenu(girisYapildi, girisYapanKullanici);
                    break;
                case 2:
                    kitapIslemleriMenu(girisYapildi, girisYapanKullanici);
                    break;
                case 0:
                    programDevam = false;
                    System.out.println("Programdan çıkılıyor...");
                    break;
                default:
                    System.out.println("Geçersiz seçim.");
            }
        }
        scan.close();
    }

    private void kullaniciIslemleriMenu(boolean girisYapildi, String girisYapanKullanici) {
        System.out.println("1 - Kayıt Ol");
        System.out.println("2 - Giriş Yap");
        System.out.print("Seçiminiz: ");
        int kullaniciSecim = scan.nextInt();
        scan.nextLine();

        if (kullaniciSecim == 1) {
            kayitOl();
        } else if (kullaniciSecim == 2) {
            girisYapildi = girisYap(girisYapildi, girisYapanKullanici);
        } else {
            System.out.println("Geçersiz seçim.");
        }
    }

    private void kayitOl() {
        Kullanici_sınıf yeniKullanici = new Kullanici_sınıf("", "", "", "");

        System.out.print("İsim: ");
        yeniKullanici.setIsim(scan.nextLine());

        System.out.print("Mail: ");
        yeniKullanici.setMail(scan.nextLine());

        System.out.print("Telefon: ");
        yeniKullanici.setTelNo(scan.nextLine());

        System.out.print("Şifre: ");
        yeniKullanici.setSifre(scan.nextLine());

        boolean kayitSonucu = kullaniciIslemleri.kullaniciEkle(yeniKullanici);
        if (kayitSonucu) {
            System.out.println("Kayıt başarılı!");
        } else {
            System.out.println("Kayıt sırasında hata oluştu.");
        }
    }

    private boolean girisYap(boolean girisYapildi, String girisYapanKullanici) {
        System.out.print("İsim girin: ");
        String isim = scan.nextLine();

        System.out.print("Şifre girin: ");
        String sifre = scan.nextLine();

        boolean girisDurumu = kullaniciIslemleri.girisYap(isim, sifre);
        if (girisDurumu) {
            System.out.println("Giriş başarılı!");
            girisYapildi = true;
            girisYapanKullanici = isim;
            kullaniciKitapIslemleri(girisYapanKullanici);
        } else {
            System.out.println("Giriş başarısız. Lütfen kayıt olun.");
        }
        return girisYapildi;
    }

    private void kullaniciKitapIslemleri(String girisYapanKullanici) {
        boolean kitapIslemDevam = true;
        while (kitapIslemDevam) {
            System.out.println("\nKullanici Kitap İşlemleri:");
            System.out.println("1 - Kitap Ödünç Al");
            System.out.println("2 - Kitap İade Et");
            System.out.println("0 - Ana Menüye Dön");
            System.out.print("Seçiminiz: ");
            
            int kitapSecim = scan.nextInt();
            scan.nextLine();

            switch (kitapSecim) {
                case 1:
                    kitapOduncAl(girisYapanKullanici);
                    break;
                case 2:
                    kitapIadeEt(girisYapanKullanici);
                    break;
                case 0:
                    kitapIslemDevam = false;
                    System.out.println("Ana menüye dönülüyor...");
                    break;
                default:
                    System.out.println("Geçersiz seçim.");
            }
        }
    }

    private void kitapOduncAl(String girisYapanKullanici) {
        System.out.print("Ödünç alınacak kitabın adını girin: ");
        String kitapAdi = scan.nextLine();

        if (kitapIslemleri.kitapStokKontrol(kitapAdi)) {
            boolean basarili = kitapIslemleri.kitapOduncAl(girisYapanKullanici, kitapAdi);
            if (basarili) {
                System.out.println("Kitap ödünç alındı.");
            } else {
                System.out.println("İşlem başarısız.");
            }
        } else {
            System.out.println("Kitap şu anda mevcut değil veya stokta yok.");
        }
    }

    private void kitapIadeEt(String girisYapanKullanici) {
        System.out.print("İade edilecek kitabın adını girin: ");
        String kitapAdi = scan.nextLine();

        boolean basarili = kitapIslemleri.kitapIadeEt(girisYapanKullanici, kitapAdi);

        if (basarili) {
            System.out.println("Kitap başarıyla iade edildi.");
        } else {
            System.out.println("İade işlemi başarısız. Kitap zaten iade edilmiş veya kayıt bulunamadı.");
        }
    }

    private void kitapIslemleriMenu(boolean girisYapildi, String girisYapanKullanici) {
        boolean kitapIslemDevam = true;
        while (kitapIslemDevam) {
            System.out.println("\nKitap İşlemleri:");
            System.out.println("1 - Kitap Ekle");
            System.out.println("2 - Kitap Güncelle");
            System.out.println("3 - Kitap Ara");
            System.out.println("0 - Ana Menüye Dön");
            System.out.print("Seçiminiz: ");
            
            int kitapSecim = scan.nextInt();
            scan.nextLine();

            switch (kitapSecim) {
                case 1:
                    kitapEkle();
                    break;
                case 2:
                    kitapGuncelle();
                    break;
                case 3:
                    kitapAra();
                    break;
                case 0:
                    kitapIslemDevam = false;
                    System.out.println("Ana menüye dönülüyor...");
                    break;
                default:
                    System.out.println("Geçersiz seçim.");
            }
        }
    }

    private void kitapEkle() {
        System.out.print("Kitap adı: ");
        String kitapAd = scan.nextLine();
        System.out.print("Yazar: ");
        String yazar = scan.nextLine();
        System.out.print("Yayınevi: ");
        String yayinevi = scan.nextLine();
        System.out.print("Stok: ");
        int stok = scan.nextInt();
        scan.nextLine();
        System.out.print("Durum: ");
        String durum = scan.nextLine();

        Kitap_sınıf yeniKitap = new Kitap_sınıf(kitapAd, yazar, yayinevi, stok, durum);
        boolean eklendi = kitapIslemleri.kitapEkle(yeniKitap);
        if (eklendi) {
            System.out.println("Kitap başarıyla eklendi.");
        } else {
            System.out.println("Ekleme başarısız.");
        }
    }

    private void kitapGuncelle() {
        System.out.print("Güncellenecek kitap adı: ");
        String guncellenecekAd = scan.nextLine();
        System.out.print("Yeni stok: ");
        int yeniStok = scan.nextInt();
        scan.nextLine();
        System.out.print("Yeni durum: ");
        String yeniDurum = scan.nextLine();

        boolean guncellendi = kitapIslemleri.kitapGuncelle(guncellenecekAd, yeniStok, yeniDurum);
        if (guncellendi) {
            System.out.println("Kitap başarıyla güncellendi.");
        } else {
            System.out.println("Güncelleme başarısız.");
        }
    }

    private void kitapAra() {
        System.out.print("Aranacak kitap adı: ");
        String aranan = scan.nextLine();
        kitapIslemleri.kitapAra(aranan);
    }
}