package Baglanti;

import java.sql.*;

public class KullaniciDepo implements IKullaniciIslemleri {
    private final IVeritabaniBaglantisi baglanti;

    public KullaniciDepo(IVeritabaniBaglantisi baglanti) {
        this.baglanti = baglanti;
    }

    @Override
    public boolean kullaniciEkle(Kullanici_sınıf k) {
        try (Connection conn = baglanti.baglan()) {
            String sql = "INSERT INTO kullanici (isim, email, telefon, sifre) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, k.getIsim());
            stmt.setString(2, k.getMail());
            stmt.setString(3, k.getTelNo());
            stmt.setString(4, k.getSifre());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Kayıt hatası: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean girisYap(String isim, String sifre) {
        try (Connection conn = baglanti.baglan()) {
            String sql = "SELECT * FROM kullanici WHERE isim = ? AND sifre = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, isim);
            stmt.setString(2, sifre);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.out.println("Giriş hatası: " + e.getMessage());
            return false;
        }
    }
}



