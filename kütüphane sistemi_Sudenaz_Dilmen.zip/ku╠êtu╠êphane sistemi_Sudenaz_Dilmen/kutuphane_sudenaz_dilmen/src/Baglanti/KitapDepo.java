package Baglanti;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;

public class KitapDepo implements IKitapIslemleri {
    private final IVeritabaniBaglantisi baglanti;

    public KitapDepo(IVeritabaniBaglantisi baglanti) {
        this.baglanti = baglanti;
    }

    @Override
    public boolean kitapEkle(Kitap_sınıf kitap) {
        try (Connection conn = baglanti.baglan()) {
            String sql = "INSERT INTO kitap (ad, yazar, yayinevi, stok, durum) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, kitap.getAd());
            stmt.setString(2, kitap.getYazar());
            stmt.setString(3, kitap.getYayinevi());
            stmt.setInt(4, kitap.getStok());
            stmt.setString(5, kitap.getDurum());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Kitap ekleme hatası: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean kitapGuncelle(String ad, int yeniStok, String yeniDurum) {
        try (Connection conn = baglanti.baglan()) {
            String sql = "UPDATE kitap SET stok = ?, durum = ? WHERE ad = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, yeniStok);
            stmt.setString(2, yeniDurum);
            stmt.setString(3, ad);
            int guncellenen = stmt.executeUpdate();
            return guncellenen > 0;
        } catch (SQLException e) {
            System.out.println("Güncelleme hatası: " + e.getMessage());
            return false;
        }
    }

    @Override
    public void kitapAra(String arananAd) {
        try (Connection conn = baglanti.baglan()) {
            String sql = "SELECT * FROM kitap WHERE ad LIKE ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, "%" + arananAd + "%");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") +
                                 ", Ad: " + rs.getString("ad") +
                                 ", Yazar: " + rs.getString("yazar") +
                                 ", Yayınevi: " + rs.getString("yayinevi") +
                                 ", Stok: " + rs.getInt("stok") +
                                 ", Durum: " + rs.getString("durum"));
            }
        } catch (SQLException e) {
            System.out.println("Arama hatası: " + e.getMessage());
        }
    }

    @Override
    public boolean kitapStokKontrol(String kitapAdi) {
        String query = "SELECT stok, durum FROM kitap WHERE ad = ?";
        try (Connection conn = baglanti.baglan();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, kitapAdi);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int stok = rs.getInt("stok");
                String durum = rs.getString("durum");
                return stok > 0 && durum.equalsIgnoreCase("mevcut");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean kitapOduncAl(String kullaniciAdi, String kitapAdi) {
        String kitapIdQuery = "SELECT id, stok FROM kitap WHERE ad = ?";
        String kullaniciIdQuery = "SELECT id FROM kullanici WHERE isim = ?";
        String oduncEkle = "INSERT INTO odunc (kullanici_id, kitap_id, alis_tarihi, teslim_edildi) VALUES (?, ?, NOW(), false)";
        String stokGuncelle = "UPDATE kitap SET stok = ?, durum = ? WHERE id = ?";
        String bildirimEkle = "INSERT INTO bildirim (kullanici_id, mesaj, gonderim_tarihi) VALUES (?, ?, NOW())";

        try (Connection conn = baglanti.baglan()) {
            conn.setAutoCommit(false);

            int kitapId = -1, kullaniciId = -1, stok = -1;

            try (PreparedStatement stmt = conn.prepareStatement(kitapIdQuery)) {
                stmt.setString(1, kitapAdi);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    kitapId = rs.getInt("id");
                    stok = rs.getInt("stok");
                }
            }

            try (PreparedStatement stmt = conn.prepareStatement(kullaniciIdQuery)) {
                stmt.setString(1, kullaniciAdi);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    kullaniciId = rs.getInt("id");
                }
            }

            if (kitapId == -1 || kullaniciId == -1 || stok <= 0) {
                conn.rollback();
                return false;
            }

            try (PreparedStatement oduncStmt = conn.prepareStatement(oduncEkle);
                 PreparedStatement stokStmt = conn.prepareStatement(stokGuncelle);
                 PreparedStatement bildirimStmt = conn.prepareStatement(bildirimEkle)) {

                oduncStmt.setInt(1, kullaniciId);
                oduncStmt.setInt(2, kitapId);
                oduncStmt.executeUpdate();

                int yeniStok = stok - 1;
                String yeniDurum = (yeniStok == 0) ? "ödünç" : "mevcut";

                stokStmt.setInt(1, yeniStok);
                stokStmt.setString(2, yeniDurum);
                stokStmt.setInt(3, kitapId);
                stokStmt.executeUpdate();

                String mesaj = "Kullanıcı '" + kullaniciAdi + "', '" + kitapAdi +
                               "' adlı kitabı " + java.time.LocalDate.now() + " tarihinde ödünç aldı.";
                bildirimStmt.setInt(1, kullaniciId);
                bildirimStmt.setString(2, mesaj);
                bildirimStmt.executeUpdate();
                
                System.out.println(mesaj);
            }

            conn.commit();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean kitapIadeEt(String kullaniciAdi, String kitapAdi) {
        String kitapIdQuery = "SELECT id, stok FROM kitap WHERE ad = ?";
        String kullaniciIdQuery = "SELECT id FROM kullanici WHERE isim = ?";
        String oduncGuncelle = "UPDATE odunc SET iade_tarihi = NOW(), teslim_edildi = true WHERE kullanici_id = ? AND kitap_id = ? AND teslim_edildi = false";
        String stokGuncelle = "UPDATE kitap SET stok = ?, durum = ? WHERE id = ?";
        String bildirimEkle = "INSERT INTO bildirim (kullanici_id, mesaj, gonderim_tarihi) VALUES (?, ?, NOW())";

        try (Connection conn = baglanti.baglan()) {
            conn.setAutoCommit(false);

            int kitapId = -1, kullaniciId = -1, stok = -1;

            try (PreparedStatement stmt = conn.prepareStatement(kitapIdQuery)) {
                stmt.setString(1, kitapAdi);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    kitapId = rs.getInt("id");
                    stok = rs.getInt("stok");
                }
            }

            try (PreparedStatement stmt = conn.prepareStatement(kullaniciIdQuery)) {
                stmt.setString(1, kullaniciAdi);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    kullaniciId = rs.getInt("id");
                }
            }

            if (kitapId == -1 || kullaniciId == -1) {
                conn.rollback();
                return false;
            }

            try (PreparedStatement iadeStmt = conn.prepareStatement(oduncGuncelle);
                 PreparedStatement stokStmt = conn.prepareStatement(stokGuncelle);
                 PreparedStatement bildirimStmt = conn.prepareStatement(bildirimEkle)) {

                iadeStmt.setInt(1, kullaniciId);
                iadeStmt.setInt(2, kitapId);
                int updated = iadeStmt.executeUpdate();

                if (updated == 0) {
                    conn.rollback();
                    return false;
                }

                int yeniStok = stok + 1;
                String yeniDurum = "mevcut";

                stokStmt.setInt(1, yeniStok);
                stokStmt.setString(2, yeniDurum);
                stokStmt.setInt(3, kitapId);
                stokStmt.executeUpdate();

                String mesaj = "Kullanıcı '" + kullaniciAdi + "', '" + kitapAdi +
                               "' adlı kitabı " + java.time.LocalDate.now() + " tarihinde iade etti.";
                bildirimStmt.setInt(1, kullaniciId);
                bildirimStmt.setString(2, mesaj);
                bildirimStmt.executeUpdate();
                
                System.out.println(mesaj);
            }

            conn.commit();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}