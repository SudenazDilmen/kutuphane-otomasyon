package Baglanti;

public interface IKullaniciIslemleri {
    boolean kullaniciEkle(Kullanici_sınıf kullanici);
    boolean girisYap(String isim, String sifre);
}
