package Baglanti;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MySQLVeritabaniBaglantisi implements IVeritabaniBaglantisi {
    private static final String URL = "jdbc:mysql://localhost:3306/kutuphane?useSSL=false";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    @Override
    public com.mysql.jdbc.Connection baglan() throws SQLException {
        return (com.mysql.jdbc.Connection) DriverManager.getConnection(URL, USER, PASSWORD);
    }
}