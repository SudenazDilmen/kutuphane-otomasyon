# 📚 Kütüphane Yönetim Sistemi

Java ile SOLID prensiplerine uygun geliştirilmiş kütüphane otomasyonu.

## 🛠 Kurulum
1. JDK 11+ yükleyin.
2. `git clone https://github.com/sizin-repo/kutuphane-sistemi.git`
3. MySQL'de `kutuphane` veritabanını oluşturun.

## 🚀 Kullanım
```java
// Main.java dosyasını çalıştırın